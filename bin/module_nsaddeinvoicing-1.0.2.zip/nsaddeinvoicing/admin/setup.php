<?php
/* Copyright (C) 2004-2017 Laurent Destailleur  <eldy@users.sourceforge.net>
 * Copyright (C) 2026      Nicolas Silobre      <contact@ns-info.fr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    nsaddeinvoicing/admin/setup.php
 * \ingroup nsaddeinvoicing
 * \brief   Nsaddeinvoicing setup page.
 */

// Chargement de l'environnement Dolibarr
$res = 0;
// Essai de main.inc.php dans la racine web connue, définie dans CONTEXT_DOCUMENT_ROOT (pas toujours définie)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
// Essai de main.inc.php dans la racine web détectée à partir de SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) { $i--; $j--; }
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
// Essai de main.inc.php avec un chemin relatif
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

global $langs, $user, $conf, $db;

// Libraries
require_once DOL_DOCUMENT_ROOT.'/core/lib/admin.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.formother.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.form.class.php';
dol_include_once('/nsaddeinvoicing/lib/nsaddeinvoicing.lib.php');
dol_include_once('/nsinfo/lib/setup.lib.php');

// Translations
$langs->loadLangs(array("admin", "nsinfo@nsinfo", "nsaddeinvoicing@nsaddeinvoicing"));

// Contrôle d'accès
if (!$user->admin) accessforbidden();

// Parameters
$action = GETPOST('action', 'alpha');
$backtopage = GETPOST('backtopage', 'alpha');
$var = GETPOST('var', 'alpha');
$vartxt = GETPOST('vartxt', 'alpha');
$value = GETPOST($var, 'alpha');
$valuetxt = GETPOST($vartxt, 'alpha');
$varcolor = GETPOST('varcolor', 'alpha');
$varround = GETPOST('varround', 'alpha');
$value = GETPOST('value', 'alpha');
$varlist = GETPOST('varlst', 'aZ09');	// Types listsel / seltags / multilistsel de nsinfoSetup()


$arrayofparameters = array(
	'NSADDEINVOICING_GENERAL1'	=> array('type' => 'titletab', 'title' => 'NSADDEINVOICING_GENERAL1'),
	'TABDEB' 						=> array('type' => 'tabdeb'),
	'NSADDEINVOICING_DROPDOWN_OVERFLOW'	=> array('type' => 'bool', 'default' => 0, 'Tooltip' => 1),
	'NSADDEINVOICING_POPUP_HEIGHT'		=> array('type' => 'bool', 'default' => 0, 'Tooltip' => 1),
	'TABFIN1' 						=> array('type' => 'tabfin'),
);


$error = 0;
$setupnotempty = 0;
$defaultvalue = isset($arrayofparameters[$var]['default']) ? $arrayofparameters[$var]['default'] : '';

/*
 * Actions
 */

include DOL_DOCUMENT_ROOT.'/core/actions_setmoduleoptions.inc.php';

nsinfoAction($action, $var, $value, $vartxt, $varround, $valuetxt, $defaultvalue, $varcolor, $varlist, '', '', $arrayofparameters);


/*
 * View
 */
$formother = new FormOther($db);
$form = new Form($db);


$page_name = "NsaddeinvoicingSetup";
llxHeader('', $langs->trans($page_name));

// Subheader
$linkback = '<a href="'.($backtopage ? $backtopage : DOL_URL_ROOT.'/admin/modules.php?restore_lastsearch_values=1').'">'.$langs->trans("BackToModuleList").'</a>';

print load_fiche_titre($langs->trans($page_name), $linkback, 'object_nsaddeinvoicing@nsaddeinvoicing');

// En-tête de la configuration
$head = nsaddeinvoicingAdminPrepareHead();
print dol_get_fiche_head($head, 'settings', $langs->trans("Settings"), -1, "nsaddeinvoicing@nsaddeinvoicing");

nsinfoSetup($arrayofparameters);

// Fin de page
print dol_get_fiche_end();

llxFooter();
$db->close();
