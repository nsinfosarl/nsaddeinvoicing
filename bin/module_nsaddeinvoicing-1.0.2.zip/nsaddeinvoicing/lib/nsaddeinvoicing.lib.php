<?php
/* Copyright (C) 2026		Nicolas Silobre					<contact@ns-info.fr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    nsaddeinvoicing/lib/nsaddeinvoicing.lib.php
 * \ingroup nsaddeinvoicing
 * \brief   Fichiers de bibliothèque avec les fonctions communes de Nsaddeinvoicing
 */

dol_include_once('/nsinfo/backport/backport.inc.php');	// Framework NSINFO : fonctions de Dolibarr 23 utilisées par les pages générées par ModuleBuilder

/**
 * Prépare l'en-tête des pages d'administration
 *
 * @return array
 */
function nsaddeinvoicingAdminPrepareHead()
{
	global $db, $langs, $conf;

	$langs->loadLangs(array("admin", "nsinfo@nsinfo", "nsaddeinvoicing@nsaddeinvoicing"));

	$h = 0;
	$head = array();

	$head[$h][0] = dol_buildpath("/nsaddeinvoicing/admin/setup.php", 1);
	$head[$h][1] = '<i class="fas fa-cogs paddingright pictofixedwidth valignmiddle" style="color: #5A2D82"></i>' . $langs->trans("Settings");
	$head[$h][2] = 'settings';
	$h++;

	// Onglet principal des champs supplémentaires des objets (un sous-onglet par objet : nsaddeinvoicingExtrafieldsPrepareHead())
	$nbextrafields = 0;
	$extrafieldshead = nsaddeinvoicingExtrafieldsPrepareHead($nbextrafields);
	if (count($extrafieldshead)) {
		$head[$h][0] = $extrafieldshead[0][0];
		$head[$h][1] = '<i class="fas fa-th-list paddingright pictofixedwidth valignmiddle" style="color: #22A7D8"></i>'.$langs->trans('ExtraFields');
		if ($nbextrafields > 0) {
			$head[$h][1] .= '<span class="badge marginleftonlyshort">'.$nbextrafields.'</span>';
		}
		$head[$h][2] = 'extrafields';
		$h++;
	}

	if (getDolGlobalString('MAIN_MULTILANGS')) {
		$head[$h][0] = dol_buildpath("/nsinfo/admin/trad_module.php?namemodule=nsaddeinvoicing", 1);
		$head[$h][1] = '<i class="fas fa-robot paddingright pictofixedwidth valignmiddle" style="color: #2E7D32"></i>' . $langs->trans("NsinfoTradTab");
		$head[$h][2] = 'trad';
		$h++;
	}

	$head[$h][0] = dol_buildpath("/nsinfo/admin/config_module.php?namemodule=nsaddeinvoicing", 1);
	$head[$h][1] = '<i class="fas fa-save paddingright pictofixedwidth valignmiddle" style="color: #2E9E5B"></i>' . $langs->trans("NsinfoCfgTab");
	$head[$h][2] = 'configmodule';
	$h++;

	$head[$h][0] = dol_buildpath("/nsinfo/admin/changelog_module.php?namemodule=nsaddeinvoicing", 1);
	$head[$h][1] = '<i class="fas fa-code-branch paddingright pictofixedwidth valignmiddle" style="color: #3879B2"></i>' . $langs->trans("NSINFOChangeLog");
	$head[$h][2] = 'changelog';
	$h++;


	$head[$h][0] = dol_buildpath("/nsinfo/admin/about_module.php?namemodule=nsaddeinvoicing", 1);
	$head[$h][1] = '<i class="fab fa-readme paddingright pictofixedwidth valignmiddle" style="color: #14182B"></i>' . $langs->trans("About");
	$head[$h][2] = 'about';
	$h++;

	complete_head_from_modules($conf, $langs, null, $head, $h, 'nsaddeinvoicing');

	return $head;
}

/**
 * Prépare les sous-onglets des champs supplémentaires des objets du module (configuration, onglet "Extrafields")
 *
 * @param	int		$total		Nombre total de champs supplémentaires des objets (sortie)
 * @return	array<int,array<int,string>>
 */
function nsaddeinvoicingExtrafieldsPrepareHead(&$total = 0)
{
	global $db, $langs;

	require_once DOL_DOCUMENT_ROOT.'/core/class/extrafields.class.php';
	$langs->loadLangs(array("admin", "nsaddeinvoicing@nsaddeinvoicing"));

	// Objets du module avec des champs supplémentaires : clé de l'objet => array(clé de traduction du libellé, picto de l'objet)
	$objects = array(
		// BEGIN OBJECTS WITH EXTRAFIELDS (completed by scripts/objet_aligner.py of the skill)
		// END OBJECTS WITH EXTRAFIELDS
	);

	$extrafields = new ExtraFields($db);
	$total = 0;
	$h = 0;
	$head = array();
	foreach ($objects as $objectkey => $objectdesc) {
		list($objectlabel, $objectpicto) = (is_array($objectdesc) ? $objectdesc : array($objectdesc, ''));
		$extrafields->fetch_name_optionals_label('nsaddeinvoicing_'.$objectkey);
		$nb = (isset($extrafields->attributes['nsaddeinvoicing_'.$objectkey]['label']) && is_countable($extrafields->attributes['nsaddeinvoicing_'.$objectkey]['label'])) ? count($extrafields->attributes['nsaddeinvoicing_'.$objectkey]['label']) : 0;
		$total += $nb;
		$head[$h][0] = dol_buildpath('/nsaddeinvoicing/admin/'.$objectkey.'_extrafields.php', 1);
		$head[$h][1] = ($objectpicto ? img_picto('', $objectpicto, 'class="pictofixedwidth"') : '').$langs->trans($objectlabel).($nb > 0 ? '<span class="badge marginleftonlyshort">'.$nb.'</span>' : '');
		$head[$h][2] = $objectkey.'_extrafields';
		$h++;
	}

	return $head;
}
