# NsAddEInvoicing — Complément e-invoicing

Fiche de présentation du module pour **Dolistore.com** (version française puis version anglaise).

---

# 🇫🇷 Version française

## Nom du module

**NsAddEInvoicing – Factures fournisseur e-invoicing : changez les références, supprimez des lignes**

## Description courte

Complétez vos factures fournisseur reçues en facturation électronique : cochez plusieurs lignes, changez leurs références parmi les produits du fournisseur ou supprimez-les en une fois, avec recalcul des totaux. Sans modifier le Core.

## Description longue

### Fini les corrections ligne par ligne

Une facture fournisseur reçue en facturation électronique arrive en brouillon, avec des références de lignes à corriger ou à rattacher à vos produits.

**NsAddEInvoicing** vous permet de le faire en une seule fois, sur plusieurs lignes à la fois.

### Simple à utiliser

- Une **case à cocher** sur chaque ligne d'une facture fournisseur au statut brouillon, et une case pour **tout cocher**.
- Une **liste d'actions** apparaît dès qu'une ligne est cochée.
- **Changer la référence** : la référence en cours est affichée, vous choisissez la nouvelle parmi les **produits du fournisseur de la facture**.
- **Supprimer les lignes** cochées, avec confirmation et recalcul des totaux de la facture.

### Sans risque

- Libellé, prix, quantités, TVA et totaux ne changent pas lors d'un changement de référence.
- Aucun réglage à faire : le module est prêt à l'emploi dès son activation.
- Cohabite avec NsDTools : sur les factures fournisseur en brouillon, c'est NsAddEInvoicing qui prend le relais.

## Points forts

- ✅ Actions groupées sur les lignes des factures fournisseur en brouillon
- ✅ Nouvelle référence choisie parmi les seuls produits du fournisseur
- ✅ Suppression groupée avec recalcul des totaux
- ✅ Aucun droit supplémentaire à gérer
- ✅ Sans modification du Core
- ✅ Module gratuit

## Compatibilité

- Dolibarr **20.0 à 24**
- PHP **7.4 à 8.3**
- **Prérequis : framework NSINFO (module NSINFO) version 23.8.0 ou supérieure**, installé et activé
- Langues : français, anglais, allemand, espagnol, italien

## Mots-clés

facture fournisseur, e-invoicing, facturation électronique, factur-x, lignes de facture, changer la référence, suppression de lignes, actions de masse, NSINFO

---

# 🇬🇧 English version

## Module name

**NsAddEInvoicing – E-invoicing supplier invoices: fix references and delete lines in one go**

## Short description

Complete your supplier invoices received by electronic invoicing: tick several lines, change their references among the supplier's products or delete them in one go, with totals recalculated. No change to the Core.

## Long description

### No more line-by-line fixes

A supplier invoice received by electronic invoicing arrives as a draft, with line references to correct or to link to your products.

**NsAddEInvoicing** lets you do it in one go, on several lines at once.

### Easy to use

- A **checkbox** on each line of a draft supplier invoice, and a box to **tick all**.
- An **action list** appears as soon as a line is ticked.
- **Change the reference**: the current reference is shown and you choose the new one among the **products of the invoice's supplier**.
- **Delete the ticked lines**, with confirmation and recalculation of the invoice totals.

### Safe

- Label, prices, quantities, VAT and totals do not change when a reference is changed.
- Nothing to configure: the module is ready to use as soon as it is enabled.
- Coexists with NsDTools: on draft supplier invoices, NsAddEInvoicing takes over.

## Highlights

- ✅ Bulk actions on the lines of draft supplier invoices
- ✅ New reference chosen among the supplier's products only
- ✅ Bulk deletion with recalculation of the totals
- ✅ No additional rights to manage
- ✅ No change to the Core
- ✅ Free module

## Compatibility

- Dolibarr **20.0 to 24**
- PHP **7.4 to 8.3**
- **Prerequisite: NSINFO framework (NSINFO module) version 23.8.0 or higher**, installed and enabled
- Languages: French, English, German, Spanish, Italian

## Keywords

supplier invoice, e-invoicing, electronic invoicing, factur-x, invoice lines, change reference, delete lines, bulk actions, NSINFO
